package hoonstudio.com.fitnow

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExerciseCategoryRepository{

    lateinit private var exerciseCategoryDao: ExerciseCategoryDao
    lateinit private var allExerciseCategory: LiveData<List<ExerciseCategory>>
    private val scope = CoroutineScope(Dispatchers.Default)

    constructor(application: Application) {
        val database = ExerciseCategoryDatabase.getInstance(application)!!
        exerciseCategoryDao = database.exerciseCategoryDao()
        initExerciseCategory()
    }

    fun initExerciseCategory() = scope.launch {
        allExerciseCategory = exerciseCategoryDao.getAllCategories()
    }

    fun insert(exerciseCategory: ExerciseCategory){
        InsertExerciseCategory(exerciseCategoryDao).insert(exerciseCategory)
    }

    fun update(exerciseCategory: ExerciseCategory){

    }

    fun delete(exerciseCategory: ExerciseCategory){

    }

    fun deleteAllExerciseCategory(){

    }

    fun getAllExerciseCategory(): LiveData<List<ExerciseCategory>>{
        return allExerciseCategory
    }


    companion object{
        private class InsertExerciseCategory internal constructor(private val exerciseCategoryDao: ExerciseCategoryDao?){
            private val scope = CoroutineScope(Dispatchers.Default)

            fun insert(exerciseCategory: ExerciseCategory) = scope.launch{
                exerciseCategoryDao?.insert(exerciseCategory)
            }
        }
    }
}