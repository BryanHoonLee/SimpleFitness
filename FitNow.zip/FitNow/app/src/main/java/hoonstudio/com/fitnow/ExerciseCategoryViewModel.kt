package hoonstudio.com.fitnow

import android.app.Application
import androidx.annotation.NonNull
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class ExerciseCategoryViewModel  : AndroidViewModel {

    private var app: Application
    private var exerciseCategoryRepository: ExerciseCategoryRepository
    private var allExerciseCategory: LiveData<List<ExerciseCategory>>

    constructor(@NonNull app: Application) : super(app){
        this.app = app
        exerciseCategoryRepository = ExerciseCategoryRepository(app)
        allExerciseCategory = exerciseCategoryRepository.getAllExerciseCategory()
    }

    fun insert(exerciseCategory: ExerciseCategory){
        exerciseCategoryRepository.insert(exerciseCategory)
    }

    fun update(exerciseCategory: ExerciseCategory){
        exerciseCategoryRepository.update(exerciseCategory)
    }

    fun delete(exerciseCategory: ExerciseCategory){
        exerciseCategoryRepository.delete(exerciseCategory)
    }

    fun deleteAllExerciseCategory(){
        exerciseCategoryRepository.deleteAllExerciseCategory()
    }

    fun getAllExerciseCategory(): LiveData<List<ExerciseCategory>>{
        return allExerciseCategory
    }


}