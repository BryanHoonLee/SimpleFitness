package hoonstudio.com.fitnow

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.annotation.Nullable
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders

class MainActivity : AppCompatActivity() {
    lateinit private var exerciseCategoryViewModel: ExerciseCategoryViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // you pass an activity or fragment in .of so that the view model knows which lifecycle it has to be scoped to.
        // in this case the android system will destroy this view model when this activity is finished.
        exerciseCategoryViewModel = ViewModelProviders.of(this).get(ExerciseCategoryViewModel::class.java)

        // since getAll returns live data, we can use the live data method observe.
        // takes 2 parameters. First is the lifeCycleOwner. You pass either activity or fragment. This is needed since
        // live data is lifecycle aware and it will only update the activity/fragment if it is in the foreground and also
        // clean up the reference to the activity/fragment when the activity/fragment is destroyed.
        // This avoids memory leaks and crashes.
        //
        // Second parameter takes in an observer which you can pass as an anonymous inner class.
        exerciseCategoryViewModel.getAllExerciseCategory().observe(this, Observer<List<ExerciseCategory>>{
            // update recyclerview
            Toast.makeText(this, "onChanged", Toast.LENGTH_SHORT)

        })

    }
}
